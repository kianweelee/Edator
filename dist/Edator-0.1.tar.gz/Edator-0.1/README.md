# Edator
 A python package that performs exploratory data analysis for users. Additionally, it generates 3 output files that comprise of a cleaned CSV, plots and a text report.
